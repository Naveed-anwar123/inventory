from django.apps import AppConfig


class IronStoreTransactionsConfig(AppConfig):
    name = 'iron_store_transactions'
