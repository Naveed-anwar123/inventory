from django.apps import AppConfig


class BendingPressItemsConfig(AppConfig):
    name = 'bending_press_items'
