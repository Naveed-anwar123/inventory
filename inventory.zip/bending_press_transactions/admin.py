from django.contrib import admin
from . models import IronStoreTransaction
# Register your models here.

admin.site.register(IronStoreTransaction)