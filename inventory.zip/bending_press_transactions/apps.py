from django.apps import AppConfig


class BendingPressTransactionsConfig(AppConfig):
    name = 'bending_press_transactions'
